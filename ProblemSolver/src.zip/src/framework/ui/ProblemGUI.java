/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package framework.ui;

import framework.problem.*;
import framework.solution.*;
import javafx.scene.layout.*;
import javafx.scene.control.*;
import javafx.scene.text.*;
import javafx.scene.paint.Color;
import javafx.geometry.Insets;

/**
 *
 * @author pfahn
 */
public class ProblemGUI extends VBox {
    
    public ProblemGUI(Problem problem, double width, double height) {
        this.problem = problem;
        this.width = width;
        this.height = height;
        this.setPrefSize(width, height);
        
        
        introduction = new Label(problem.getIntroduction());
        introduction.setWrapText(true);
        introduction.setFont(Font.font("Verdana", FontPosture.REGULAR, 13));
        
        
        welcome = new Label("Welcome to the: " + problem.getName() + " problem.");
        welcome.setWrapText(true);
        welcome.setFont(Font.font("Verdana", FontWeight.BOLD, FontPosture.REGULAR, 17));
        
        
        currentState = new Label(problem.getCurrentState().toString());
        currentState.setBorder(new Border(new BorderStroke(Color.BLACK, BorderStrokeStyle.SOLID, CornerRadii.EMPTY, BorderWidths.DEFAULT)));
        currentState.setPadding(new Insets(15, 25, 15, 25));
        currentState.setFont(new Font("Monospaced Bold", 15));
        
        
        goalState = new Label(problem.getFinalState().toString());
        goalState.setBorder(new Border(new BorderStroke(Color.BLACK, BorderStrokeStyle.SOLID, CornerRadii.EMPTY, BorderWidths.DEFAULT)));
        goalState.setPadding(new Insets(15, 25, 15, 25));
        goalState.setFont(new Font("Monospaced Bold", 15));
        
        box = new HBox(150);
        box.getChildren().addAll(currentState, goalState);
        
        
        super.getChildren().addAll(welcome, introduction, box);
        
        
    }
    
    private final Problem problem;
   // private final SolvingAssistant solver;
    private double width, height;
    private Label welcome;
    private Label introduction;
    private Label currentState;
    private Label goalState;
    private HBox box;
    
}
